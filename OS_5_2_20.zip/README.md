# OS_bupt
BUPT's curriculum design homework.

说明：
	1 这是北邮大三操作系统课程设计作业
	2 实现模拟一个简单的操作系统
	3 主要开发工具是QT
	4 有进程管理，内存管理，文件管理三个模块
	5 用于课程学习