#ifndef TREE_H
#define TREE_H

#include <QWidget>
#include<QTreeView>
#include<QStandardItemModel>
#include<QStandardItem>
class tree :public QTreeView
{
public:
    tree();
    treeinit();

};

#endif // TREE_H
