#pragma once
#include "File.h"
File::File(string path, string name) :path(path), name(name)
{
}
File::File()
{
}
File::~File()
{
}

